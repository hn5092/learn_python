if $mingw or $mswin
  create_makefile("-test-/win32/dln/empty")
end
