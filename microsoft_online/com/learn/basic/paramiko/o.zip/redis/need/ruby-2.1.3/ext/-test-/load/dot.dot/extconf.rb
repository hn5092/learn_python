create_makefile("-test-/load/dot.dot/dot.dot")
